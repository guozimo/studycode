/*! grafana - v2.0.2 - 2015-04-22
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache License */

define(["angular","lodash","kbn"],function(a){"use strict";var b=a.module("grafana.services");b.factory("SqlDatasource",function(){function a(){}return a})});